#ifndef INC_01_MANUAL_INPUT_HPP
#define INC_01_MANUAL_INPUT_HPP

void manual_input();

#endif
