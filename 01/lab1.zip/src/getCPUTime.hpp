#ifndef INC_01_GETCPUTIME_HPP
#define INC_01_GETCPUTIME_HPP

double getCPUTime();

#endif
