#ifndef INC_01_TIME_COMPARE_HPP
#define INC_01_TIME_COMPARE_HPP

void time_compare();

#endif
