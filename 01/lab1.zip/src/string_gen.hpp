#ifndef INC_01_STRING_GEN_HPP
#define INC_01_STRING_GEN_HPP

#include "string"
using namespace std;

string string_gen(size_t len);

#endif
